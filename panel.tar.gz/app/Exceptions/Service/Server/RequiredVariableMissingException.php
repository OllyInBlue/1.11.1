<?php

namespace Pterodactyl\Exceptions\Service\Server;

use Pterodactyl\Exceptions\PterodactylException;

class RequiredVariableMissingException extends PterodactylException
{
}
